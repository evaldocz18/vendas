import 'package:app/api/cliente_api.dart';
import 'package:app/api/produto_api.dart';
import 'package:app/api/venda_api.dart';
import 'package:app/dao/clientedao.dart';
import 'package:app/dao/vendadao.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'dao/produtodao.dart';
import 'pages/tabs_pages.dart';

void main() {
  runApp(MultiBlocProvider(
    providers: [
      BlocProvider<ClienteCubit>(create: (BuildContext context) {
        ClienteCubit cubit = ClienteCubit();
        ClienteAPI.getAllClientes().then(cubit.inserAllCliente);
        return cubit;
      }),
      BlocProvider<ProdutoCubit>(create: (BuildContext context) {
        ProdutoCubit cubit = ProdutoCubit();
        ProdutoAPI.getAll().then(cubit.insertAllProduto);
        return cubit;
      }),
      BlocProvider<VendaCubit>(create: (BuildContext context) {
        VendaCubit cubit = VendaCubit();
        VendaAPI.getAll().then(cubit.insertAllVenda);
        return cubit;
      }),
    ],
    child: MaterialApp(
      home: TabsScreen(),
    ),
  ));
}
